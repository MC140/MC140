# Workspace instructions

This repository is exclusively for Power BI semantic-model assessment and star-schema proposal generation.

- Treat `/input` as read-only.
- Write generated content only to `/output`.
- Never modify original PBIP, semantic-model, report, TMDL, BIM, Power Query, DAX, or JSON files.
- Do not configure MCP.
- Do not connect to Power BI Desktop, Fabric, Power BI Service, databases, XMLA endpoints, or external APIs.
- Do not publish, deploy, refresh, or execute generated model code.
- Use Power BI, dimensional-modelling, TMDL, DAX, and Power Query terminology accurately.
- Determine fact grain before recommending model changes.
- Preserve semantic behavior unless every change is explicitly documented.
- Mark uncertainty, inference, assumptions, and required business confirmation clearly.
- Prefer assessment and proposal artifacts over automatic conversion.
- Use Markdown for reports, CSV for mappings, and Mermaid for diagrams.
- Keep source and proposed object names visible in every mapping.
- Never describe an inferred business rule as confirmed.
- Never claim validation passed unless evidence is available.
