# Power BI Star Schema Assessor

A safe GitHub Copilot custom agent for assessing PBIP/TMDL semantic models and producing a star-schema-first redesign proposal without changing the original Power BI project.

## Purpose

The agent inventories a semantic model, determines table grain, classifies facts/dimensions/bridges, identifies modelling risks, proposes a star schema, maps source objects to proposed objects, analyzes DAX and report impact, and produces a validation plan.

It creates recommendations and proposal artifacts. It does **not** create an automatically production-ready converted model.

## Safety model

- `/input` is read-only.
- All generated artifacts go under `/output/<model-name>/`.
- No publishing, deployment, refresh, database execution, MCP, external API, Fabric, Power BI Service, XMLA, or credential access.
- Original PBIP, TMDL, BIM, DAX, Power Query, JSON, and report files are never modified.
- Every inference and assumption is labelled.

## Supported inputs

- `.pbip` project
- `.SemanticModel` folder
- TMDL `definition` folder
- `model.bim`
- Optional `.Report` folder
- Optional business rules and mapping documentation

## Unsupported inputs

A standalone binary `.pbix` cannot be safely inspected by the file-based agent. Save a copy as PBIP or provide readable semantic-model metadata.

## Project structure

```text
.github/
├── agents/
│   └── power-bi-star-schema-assessor.agent.md
└── copilot-instructions.md
standards/
templates/
input/
output/
.gitignore
README.md
```

## Prepare a PBIP copy

In Power BI Desktop, save a separate working copy as a Power BI Project (PBIP). Place that copied project under `input/<model-name>/`. Do not use the only copy of a production model.

## Run the custom agent

1. Open this folder as the VS Code workspace.
2. Open GitHub Copilot Chat.
3. Select **Power BI Star Schema Assessor** from the agent dropdown.
4. Run an assessment prompt.
5. Review the generated files under `output`.

If the agent does not appear, reload the VS Code window and verify `.github/agents/power-bi-star-schema-assessor.agent.md` has valid frontmatter.

## Expected output

```text
output/<model-name>/
├── 00-executive-summary.md
├── 01-current-model-inventory.md
├── 02-grain-analysis.md
├── 03-modeling-findings.md
├── 04-proposed-star-schema.md
├── 05-source-target-mapping.csv
├── 06-relationship-plan.md
├── 07-measure-impact-analysis.md
├── 08-report-impact-analysis.md
├── 09-validation-plan.md
├── 10-assumptions-and-confirmations.md
└── diagrams/proposed-model.mmd
```

## Example prompts

```text
Assess the Power BI semantic model under input/SalesModel. Do not modify the original model. Generate the complete assessment package under output.
```

```text
Analyze the grain of every transactional table and identify mixed-grain risks. Do not generate implementation code.
```

```text
Propose a star-schema-first redesign and generate a source-to-target mapping. Preserve measures, RLS, relationships, storage modes and report dependencies.
```

```text
Review the proposed star schema under output and identify anything that still needs business confirmation.
```

## Recommended review process

1. Confirm the agent's grain assessment with business and data owners.
2. Review proposed fact and dimension classifications.
3. Resolve every `NEEDS BUSINESS CONFIRMATION` item.
4. Review measure, RLS, storage-mode, and report impacts.
5. Create implementation artifacts only after design approval.
6. Build the proposed model in parallel.
7. Execute the validation plan before cutover.

## Limitations

Metadata cannot prove source-data uniqueness, referential integrity, performance, refresh success, or business correctness. Those require source queries, representative data, refresh tests, report regression, and human approval.
