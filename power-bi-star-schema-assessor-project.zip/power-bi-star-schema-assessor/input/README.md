# Input folder

Place a **copy** of the Power BI project under this directory.

```text
input/
└── SalesModel/
    ├── SalesModel.pbip
    ├── SalesModel.SemanticModel/
    └── SalesModel.Report/
```

Guidance:

- Do not place the only copy of a production model here.
- Prefer a duplicate project or a dedicated Git branch.
- PBIP/TMDL is preferred.
- A standalone PBIX binary cannot be safely inspected by this file-based agent.
- Do not commit sensitive data, cached model data, credentials, or secrets.
- The agent assesses metadata. It cannot confirm source-system data quality unless profiling or validation evidence is supplied.
