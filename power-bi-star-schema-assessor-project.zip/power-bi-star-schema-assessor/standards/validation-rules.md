# Validation rules

## Metadata validation
Confirm all source objects are inventoried and every proposed treatment is traceable. Validate names, data types, formats, visibility, categories, display folders, sort-by settings, storage modes, partitions, roles, and dependencies.

## Grain validation
Prove the proposed fact grain with uniqueness tests over grain-defining columns. Investigate duplicates rather than removing them automatically.

## Key validation
Test dimension business-key uniqueness, surrogate-key stability, null/blank handling, unknown members, and orphan foreign keys.

## Relationship validation
Validate cardinality, active state, filter direction, ambiguity, referential integrity, role-playing relationships, and many-to-many bridge behavior.

## DAX reconciliation
Compare source and proposed measures at total and representative slice levels. Include distinct counts, ratios, semi-additive measures, time intelligence, inactive relationships, and filter-sensitive calculations.

## RLS validation
Test each role using representative identities and confirm no access expansion or unexpected restriction after relationship or table changes.

## Report regression
Validate visuals, slicers, filters, drill-through, bookmarks, tooltips, conditional formatting, sorting, and interaction behavior. Record every remapped field.

## Refresh and storage
Confirm query folding where relevant, source load, Import/DirectQuery/Dual behavior, aggregation mappings, partition logic, incremental-refresh policy, refresh duration, and model size.

## Performance
Compare representative DAX queries, visual render times, source queries, memory use, and refresh cost. Do not infer performance improvement solely from schema shape.

## Evidence required for success
A test passes only when the expected result, actual source result, actual proposed result, evidence, and reviewer status are recorded. Missing evidence means `NOT VALIDATED`, not pass.
