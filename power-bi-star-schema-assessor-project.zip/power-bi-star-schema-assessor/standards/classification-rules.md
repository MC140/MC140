# Classification rules

## Confidence

- **High:** Multiple independent metadata signals agree.
- **Medium:** The classification is likely but relies on incomplete evidence.
- **Low:** Primarily name- or type-based inference; business confirmation is required.

## Table classifications

### Transaction fact
Definition: One row per measurable business event. Signals: transaction identifiers, event dates, foreign keys, additive values. False positives: operational master tables with many numeric attributes. Evidence: documented or inferable event grain.

### Periodic snapshot fact
Definition: One row per entity per regular period. Signals: snapshot date plus account/entity key and balances. False positives: event facts with posting dates. Evidence: repeated entities across scheduled dates.

### Accumulating snapshot fact
Definition: One row per process instance updated across milestones. Signals: several lifecycle dates and statuses. False positives: flat case tables. Evidence: stable process key and milestone semantics.

### Factless fact
Definition: Captures event or coverage without numeric measures. Signals: mostly foreign keys and dates. False positives: bridge tables. Evidence: business event or eligibility meaning.

### Dimension
Definition: Descriptive business entity at one row per member. Signals: stable business key and attributes. False positives: deduplicated extracts without uniqueness guarantees. Evidence: uniqueness and relationship role.

### Role-playing dimension
Definition: One conformed dimension used in multiple semantic roles. Signals: multiple date or employee relationships. Evidence: distinct business roles and filter behavior.

### Bridge
Definition: Resolves legitimate many-to-many membership or allocation. Signals: two or more keys, optional weighting. False positives: factless events. Evidence: membership/allocation semantics.

### Aggregate table
Definition: Pre-aggregated facts at a higher grain. Signals: grouped keys and summarized measures. Evidence: aggregation mapping or query logic.

### Disconnected helper/parameter table
Definition: Intentionally has no relationship and supports measures or UI behavior. Signals: parameter values and DAX references. False positives: forgotten relationships.

### Flat denormalized table
Definition: Combines event measures and repeated descriptive entity attributes. Signals: transaction IDs, measures, and customer/product descriptions in the same table. Evidence: repeated attributes at the event grain.

### Mixed-grain table
Definition: Contains columns or rows representing incompatible levels of detail. Signals: totals mixed with detail, repeated header values, or incompatible identifiers. Evidence: grain violations.

### Snowflaked dimension
Definition: Dimension attributes split across related dimension tables. Evidence: dimension-to-dimension relationships and shared descriptive hierarchy.

### Staging/technical/unknown
Use when the table is non-user-facing, intermediary, metadata-oriented, or insufficiently understood.

## Column classifications

- **Natural business key:** Source-system identifier with business meaning.
- **Surrogate key:** Warehouse-generated stable dimension identifier.
- **Foreign key:** Fact/bridge reference to a dimension member.
- **Degenerate dimension:** Analytical identifier retained in a fact without a separate descriptive dimension.
- **Descriptive attribute:** Label, category, hierarchy, status, or other dimension context.
- **Additive fact:** Safely sums across all relevant dimensions.
- **Semi-additive fact:** Sums across some dimensions but not all, commonly time.
- **Non-additive fact:** Ratio, percentage, average, unit rate, or value requiring specialized aggregation.
- **Date key/date attribute:** Relationship key or user-facing calendar/fiscal attribute.
- **Status/indicator:** Categorical lifecycle or boolean-style field requiring semantic interpretation.
- **Technical metadata/audit:** Load, source, batch, timestamp, or lineage information.
- **Precalculated/derived:** Value computed upstream, in Power Query, or as a calculated column.
- **Unsupported or unclear:** Insufficient evidence; mark for confirmation.

For every classification, cite metadata evidence and list common false positives. Never infer solely from names or data types.
