# Power BI modelling standards

## Principles

Use a star-schema-first approach while allowing justified exceptions. Establish the business process and exact grain before classifying facts or dimensions.

## Facts

Recognize transaction facts, periodic snapshots, accumulating snapshots, factless facts, and aggregate facts. Numeric type alone does not make a column a fact. Document additivity and valid aggregation behavior.

## Dimensions

Prefer conformed dimensions for reusable business entities. Record the natural key, proposed surrogate-key strategy, unknown-member handling, and slowly changing dimension requirements.

## Dates

Prefer one dedicated, contiguous date dimension. Use an active relationship for the primary date role and inactive relationships or role-playing dimensions for secondary date roles when justified. Preserve existing time-intelligence behavior.

## Relationships

Prefer one-to-many relationships and single-direction filtering from dimensions to facts. Use bridge tables for legitimate many-to-many business relationships. Bidirectional filtering requires documented justification and regression testing.

## Degenerate dimensions

Keep transaction identifiers such as order or case number in the fact when they have analytical value but no meaningful descriptive dimension attributes.

## Measures

Prefer explicit measures. Preserve DAX definitions, format strings, display folders, descriptions, and dependencies. Do not sum percentages, averages, ratios, or balances without validated logic.

## Calculated columns and tables

Use calculated objects only when their semantic purpose and cost are justified. Prefer upstream transformations for large or reusable business logic. Never recommend a change without considering refresh, storage, folding, and DirectQuery constraints.

## Power Query and upstream design

For enterprise-scale models, prefer dimension/fact preparation upstream. Power Query reference tables may be acceptable for prototypes or small models when query folding, refresh cost, and source behavior are understood.

## Storage modes

Preserve Import, DirectQuery, Dual, composite-model, aggregation, partition, and incremental-refresh behavior unless the proposal explicitly documents the impact and validation required.

## Security

Preserve RLS and OLS behavior. Trace role expressions and relationship dependencies before proposing table movement or key changes.

## Usability

Use business-friendly names and descriptions. Hide technical keys when appropriate. Preserve sort-by settings, data categories, formats, hierarchies, perspectives, translations, and display folders.

## Report compatibility

Treat object identity changes as potentially breaking. A logically equivalent field in another table still requires report remapping and regression testing.

## Exceptions

A flat table, snowflake, many-to-many relationship, bidirectional filter, calculated column, or multiple date table is not automatically wrong. Document the business and technical justification, impact, and validation evidence.
